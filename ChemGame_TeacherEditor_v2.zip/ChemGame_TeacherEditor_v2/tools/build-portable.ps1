$ErrorActionPreference = "Stop"
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

$ProjectRoot = Split-Path -Parent $PSScriptRoot
$Version = "43.2.0"
$RuntimeFile = "electron-v$Version-win32-x64.zip"
$ExpectedSha256 = "EBA5F5088AF40ECB364FE258809C79A5234C6ECE5A75C64722772EBA01B02786"
$CacheDir = Join-Path $ProjectRoot "_build_cache"
$RuntimeZip = Join-Path $CacheDir $RuntimeFile
$ExtractDir = Join-Path $CacheDir "electron-runtime-$Version"
$ReleaseRoot = Join-Path $ProjectRoot "release"
$AppFolderName = "ChemGame_Teacher_Windows_x64"
$AppDir = Join-Path $ReleaseRoot $AppFolderName
$AppZip = Join-Path $ReleaseRoot "$AppFolderName.zip"

function Write-Step([string]$Text) { Write-Host "`n==> $Text" -ForegroundColor Cyan }

function Download-File([string]$Url, [string]$Destination) {
    Write-Host "Downloading: $Url"
    if (Get-Command curl.exe -ErrorAction SilentlyContinue) {
        & curl.exe -L --fail --retry 3 --retry-delay 2 --connect-timeout 20 -o $Destination $Url
        if ($LASTEXITCODE -eq 0 -and (Test-Path $Destination)) { return $true }
    }
    try {
        Invoke-WebRequest -Uri $Url -OutFile $Destination -UseBasicParsing -TimeoutSec 1800
        return (Test-Path $Destination)
    } catch { Write-Warning $_.Exception.Message; return $false }
}

Write-Step "Checking project files"
$Required = @(
    "main.js", "preload.js", "package.json",
    "content\index.html", "content\game.html", "content\editor.html",
    "content\data\manifest.json",
    "content\data\chapters\01_intro\chapter.json",
    "content\data\chapters\02_change\chapter.json",
    "content\js\data-loader.js", "content\js\app.js", "content\js\game.js",
    "content\js\storage.js", "content\js\audio.js", "content\js\effects.js", "content\js\validator.js",
    "content\editor\editor.js", "content\editor\editor.css"
)
foreach ($Relative in $Required) {
    if (-not (Test-Path (Join-Path $ProjectRoot $Relative))) { throw "Missing project file: $Relative" }
}

New-Item -ItemType Directory -Force -Path $CacheDir | Out-Null
New-Item -ItemType Directory -Force -Path $ReleaseRoot | Out-Null

if (-not (Test-Path $RuntimeZip)) {
    Write-Step "Downloading Electron $Version Windows x64 runtime (about 140 MB)"
    $Urls = @(
        "https://npmmirror.com/mirrors/electron/$Version/$RuntimeFile",
        "https://mirrors.huaweicloud.com/electron/$Version/$RuntimeFile",
        "https://github.com/electron/electron/releases/download/v$Version/$RuntimeFile"
    )
    $Downloaded = $false
    foreach ($Url in $Urls) {
        Remove-Item -Force -ErrorAction SilentlyContinue $RuntimeZip
        if (Download-File $Url $RuntimeZip) { $Downloaded = $true; break }
    }
    if (-not $Downloaded) { throw "Could not download Electron runtime. Put $RuntimeFile in _build_cache, then run BUILD.cmd again." }
} else { Write-Host "Using cached runtime: $RuntimeZip" }

Write-Step "Verifying Electron runtime"
$ActualSha256 = (Get-FileHash -Path $RuntimeZip -Algorithm SHA256).Hash.ToUpperInvariant()
if ($ActualSha256 -ne $ExpectedSha256) {
    Remove-Item -Force -ErrorAction SilentlyContinue $RuntimeZip
    throw "Electron runtime SHA-256 mismatch. Bad file removed; run again."
}
Write-Host "SHA-256 OK." -ForegroundColor Green

Write-Step "Extracting Electron runtime"
if (Test-Path $ExtractDir) { Remove-Item -Recurse -Force $ExtractDir }
New-Item -ItemType Directory -Force -Path $ExtractDir | Out-Null
Expand-Archive -Path $RuntimeZip -DestinationPath $ExtractDir -Force
if (-not (Test-Path (Join-Path $ExtractDir "electron.exe"))) { throw "electron.exe not found after extraction." }

Write-Step "Assembling shared game + editor portable folder"
if (Test-Path $AppDir) { Remove-Item -Recurse -Force $AppDir }
New-Item -ItemType Directory -Force -Path $AppDir | Out-Null
Copy-Item -Path (Join-Path $ExtractDir "*") -Destination $AppDir -Recurse -Force

$ResourcesDir = Join-Path $AppDir "resources"
$DefaultAsar = Join-Path $ResourcesDir "default_app.asar"
if (Test-Path $DefaultAsar) { Remove-Item -Force $DefaultAsar }
$ResourcesApp = Join-Path $ResourcesDir "app"
if (Test-Path $ResourcesApp) { Remove-Item -Recurse -Force $ResourcesApp }
New-Item -ItemType Directory -Force -Path $ResourcesApp | Out-Null
Copy-Item (Join-Path $ProjectRoot "main.js") $ResourcesApp -Force
Copy-Item (Join-Path $ProjectRoot "preload.js") $ResourcesApp -Force
Copy-Item (Join-Path $ProjectRoot "package.json") $ResourcesApp -Force

Copy-Item (Join-Path $ProjectRoot "content") (Join-Path $AppDir "content") -Recurse -Force
New-Item -ItemType Directory -Force -Path (Join-Path $AppDir "userdata") | Out-Null
New-Item -ItemType Directory -Force -Path (Join-Path $AppDir "editor_userdata") | Out-Null
New-Item -ItemType Directory -Force -Path (Join-Path $AppDir "backups") | Out-Null
Set-Content -Path (Join-Path $AppDir "userdata\DO_NOT_DELETE.txt") -Encoding UTF8 -Value "ChemGame learning records are stored in this folder."
Set-Content -Path (Join-Path $AppDir "backups\README.txt") -Encoding UTF8 -Value "ChemGameEditor automatically keeps up to 20 question-bank backups here."

$ElectronExe = Join-Path $AppDir "electron.exe"
$GameExe = Join-Path $AppDir "ChemGame.exe"
$EditorExe = Join-Path $AppDir "ChemGameEditor.exe"
Rename-Item -Path $ElectronExe -NewName "ChemGame.exe"

# Build a tiny editor launcher so both programs share one Electron runtime.
$LauncherCode = @"
using System;
using System.Diagnostics;
using System.IO;
public static class ChemGameEditorLauncher {
    [STAThread]
    public static void Main() {
        string root = AppDomain.CurrentDomain.BaseDirectory;
        string exe = Path.Combine(root, "ChemGame.exe");
        var psi = new ProcessStartInfo();
        psi.FileName = exe;
        psi.Arguments = "--editor";
        psi.WorkingDirectory = root;
        psi.UseShellExecute = true;
        Process.Start(psi);
    }
}
"@
try {
    Add-Type -TypeDefinition $LauncherCode -OutputAssembly $EditorExe -OutputType WindowsApplication
} catch {
    Write-Warning "Could not compile the tiny editor launcher; falling back to a second Electron executable copy."
    Copy-Item $GameExe $EditorExe -Force
}

$ReadmeSource = Join-Path $ProjectRoot "TEACHER_README_CN.txt"
if (Test-Path $ReadmeSource) { Copy-Item $ReadmeSource (Join-Path $AppDir "README_CN.txt") -Force }

$BuildInfo = @"
ChemGame Teacher Portable Edition
Build time: $(Get-Date -Format "yyyy-MM-dd HH:mm:ss")
Electron: $Version
Platform: Windows x64

Game: ChemGame.exe
Editor: ChemGameEditor.exe
Question data: content\data\manifest.json + content\data\chapters
Learning records: userdata
Editor backups: backups
"@
Set-Content -Path (Join-Path $AppDir "BUILD_INFO.txt") -Encoding UTF8 -Value $BuildInfo

Write-Step "Creating final ZIP"
if (Test-Path $AppZip) { Remove-Item -Force $AppZip }
Compress-Archive -Path $AppDir -DestinationPath $AppZip -CompressionLevel Optimal

Write-Step "Done"
Write-Host "Portable folder: $AppDir" -ForegroundColor Green
Write-Host "Game EXE: $GameExe" -ForegroundColor Green
Write-Host "Editor EXE: $EditorExe" -ForegroundColor Green
Write-Host "Final ZIP: $AppZip" -ForegroundColor Green
