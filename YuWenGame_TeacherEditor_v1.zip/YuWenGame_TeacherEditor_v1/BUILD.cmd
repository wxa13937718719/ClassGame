@echo off
setlocal EnableExtensions
cd /d "%~dp0"
chcp 65001 >nul 2>&1

echo ============================================
echo YuWenGame Electron Portable Builder
echo ============================================
echo.

set "LOG=%~dp0build_log.txt"
echo Build started: %date% %time% > "%LOG%"

if not exist "%~dp0tools\build-portable.ps1" (
  echo ERROR: tools\build-portable.ps1 not found.
  echo ERROR: tools\build-portable.ps1 not found. >> "%LOG%"
  echo.
  echo Please fully extract the ZIP first, then run BUILD.cmd.
  echo.
  pause
  exit /b 2
)

echo Starting PowerShell builder...
echo.
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\build-portable.ps1" >> "%LOG%" 2>&1
set "ERR=%ERRORLEVEL%"

echo.
if "%ERR%"=="0" (
  echo Build completed successfully.
  echo Output folder: release
  echo.
  if exist "%~dp0release" start "" explorer.exe "%~dp0release"
) else (
  echo Build failed. Error code: %ERR%
  echo.
  echo The detailed error log will open in Notepad.
  echo Please send build_log.txt to ChatGPT if you need help.
  echo.
  start "" notepad.exe "%LOG%"
)

pause
exit /b %ERR%
